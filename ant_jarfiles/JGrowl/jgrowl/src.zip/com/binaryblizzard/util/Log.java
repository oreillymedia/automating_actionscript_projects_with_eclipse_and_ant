//
// $Id$
//

// Packages

package com.binaryblizzard.util;

import java.io.PrintStream;

/**
 * A Log wrapper class to provide access to logging in a uniform way.
 *
 * @version $Revision$
 */

//// TODO: Redo this to just java 4 logging or commons logging.

public final class Log {

    /** The debug flag. */

    private static boolean debug = false;

    /** Stdout. */

    private static PrintStream stdout = System.out;

    /** Stderr. */

    private static PrintStream stderr = System.err;

    /** The original system stdout. */

    private static PrintStream sysout = System.out;

    /** The original system stderr. */

    private static PrintStream syserr = System.err;

    /**
     * Set the System output streams.
     *
     * @param out The new stdout.
     * @param err The new systout.
     */

    public static synchronized void setSystemOutputs(PrintStream out, PrintStream err) {

        stdout = (out == null ? sysout : out);
        System.setOut(stdout);
        stderr = (err == null ? syserr : err);
        System.setErr(stderr);
    }

    /**
     * Set the logging output streams.
     *
     * @param out The new output stream.
     */

    public static void setOutStream(PrintStream out) {

        if (out != null)
            stdout = out;
    }

    /**
     * Set the logging error stream,
     *
     * @param err The new error stream.
     */

    public static void setErrStream(PrintStream err) {

        if (err != null)
            stderr = err;
    }

    /**
     * Get the value of the debug flag.
     *
     * @return The value of the debug flag.
     */

    public static boolean debug() {
        return debug;
    }

    /**
     * Get the value of the debug flag.
     *
     * @return The value of the debug flag.
     */

    public static boolean getDebug() {
        return debug();
    }

    /**
     * Set the value of the debug flag.
     *
     * @param debug The new value of the debug flag.
     */

    public static void setDebug(boolean debug) {
        Log.debug = debug;
    }

    /**
     * Write a debug message if the debug flag is enabled.
     *
     * @param message The message to write
     */

    public static void debug(String message) {

        if (debug)
            log(null, message);
    }

    /**
     * Write a debug message if the debug flag is enabled.
     *
     * @param obj The Object that the message is related to.
     * @param message The message to write
     */

    public static void debug(Object obj, String message) {

        if (debug)
            log(obj, message);
    }

    /**
     * Write a log message.
     *
     * @param message The message to write.
     */

    public static void log(String message) {
        log(stdout, null, message);
    }

    /**
     * Write a log message.
     *
     * @param obj The Object that the message is related to.
     * @param message The message to write.
     */

    public static void log(Object obj, String message) {
        log(stdout, obj, message);
    }

    /**
     * Write a log message to the original system stdout stream.
     *
     * @param obj The Object that the message is related to.
     * @param message The message to write.
     */

    public static void sysout(Object obj, String message) {
        log(sysout, obj, message);
    }

    /**
     * Write a log message.
     *
     * @param out The output stream to write to.
     * @param obj The Object that the message is related to.
     * @param message The message to write.
     */

    private static void log(PrintStream out, Object obj, String message) {

        // Get the class name of the given object

        String className = null;
        if (obj != null)
            className = obj.getClass().getName();

        // Format the message

        out.println("[" + new java.util.Date() + "] " + (className == null ? "" : className + ".") + message);
    }

    /**
     * Write an error message.
     *
     * @param message The message to write.
     * @param throwable The cause of the error.
     */

    public static void error(String message, Throwable throwable) {
        error(null, message, throwable);
    }

    /**
     * Write an error message.
     *
     * @param obj The Object that the error is related to.
     * @param message The message to write.
     */

    public static void error(Object obj, String message) {
        error(obj, message, null);
    }

    /**
     * Write an error message.
     *
     * @param obj The Object that the error is related to.
     * @param message The message to write.
     * @param throwable The cause of the error.
     */

    public static void error(Object obj, String message, Throwable throwable) {
        error(stderr, obj, message, throwable);
    }

    /**
     * Write an error message to the original System stderr.
     *
     * @param obj The Object that the error is related to.
     * @param message The message to write.
     * @param throwable The cause of the error.
     */

    public static void syserror(Object obj, String message, Throwable throwable) {
        error(syserr, obj, message, throwable);
    }

    /**
     * Write an error message to the original System stderr.
     *
     * @param err The error stream to write the message to.
     * @param obj The Object that the error is related to.
     * @param message The message to write.
     * @param throwable The cause of the error.
     */

    private static void error(PrintStream err, Object obj, String message, Throwable throwable) {

        // Get the class of the obj

        String className = null;
        if (obj != null)
            className = obj.getClass().getName();

        // Format and print the error and possibly a stack track if debugging is turned on

        err.println("[" + new java.util.Date() + "] ERROR: " + (className != null ? className + "." : "") + message + (((throwable != null) && ! debug)  ? ": " + throwable : ""));
        if (debug && (throwable != null))
            throwable.printStackTrace(err);
    }
}