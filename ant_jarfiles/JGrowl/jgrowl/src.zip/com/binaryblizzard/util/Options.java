//
// $Id: Options.java,v 1.1 2006/10/17 22:06:25 smartin Exp $
//

// Foundry

package com.binaryblizzard.util;
import java.util.HashMap;
import java.util.List;
import java.util.LinkedList;
import java.util.Iterator;

/**
 * Options implements a Java version of the GNU getopt library. It supports
 * options in the form:
 * <ul>
 * <li>Short -d as well as --debug.
 * <li>Arguments provide as --arg=value, --arg value, -a value
 * <li>Forced termination of option parsing with --.
 * </ul>
 *
 * @version $Revision: 1.1 $
 * @author Stephen Martin
 *
 * Copyright 2006 Stephen Martin, Binary Blizzard Software. All rights reserved.
 */

public class Options {

    /** The option has no argument. */

    public static final int NO_ARGUMENT = 0;

    /** The option has an optional argument. */

    public static final int ARGUMENT_OPTIONAL = 1;

    /** The option has a required arguement. */

    public static final int ARGUMENT_REQUIRED = 2;

    /** The application name. */

    private String name;

    /** A description of the application. */

    private String description;

    /** A list of all the options. */

    private List allOptions = new LinkedList();

    /** A table of options keyed by long option name. */

    private HashMap longOpts = new HashMap(10);

    /** A table of options keyed by short option character. */

    private HashMap shortOpts = new HashMap(10);

    /** A table of the options that were seen and their values. */

    private HashMap seenOpts;

    /** A list of remaining arguments. */

    private List remainingArgs;

    /**
     * Create a Options object.
     *
     * @param name The application name.
     * @param description  A description of the application
     */

    public Options(String name, String description) {
	this.name = name;
	this.description = description;
    }

    /**
     * Add an option.
     *
     * @param longOpt The long form of the opton.
     * @param shortOpt The short form of the option.
     * @param required A flag to indicate if the option is required.
     * @param argInfo Information about the argument, on of NO_ARGUMENT, OPTIONAL_ARGUMENT or REQUIRED_ARGUMENT.
     * @param defaultValue The default value for the option.
     * @param description A description of the option.
     */

    public void addOption(String longOpt, char shortOpt, boolean required, int argInfo, String defaultValue, String description) {

	// Create the option and register it with the option tables

	Option option = new Option(shortOpt,  longOpt,  description, argInfo, required, defaultValue);
	addOption(option);
    }

    public void addOption(Option option) {
         allOptions.add(option);
	if (option.getLongOpt() != null)
	   longOpts.put(option.getLongOpt(), option);
	if (option.getShortOpt() != (char) 0)
	   shortOpts.put(new Character(option.getShortOpt()), option);
    }

    /**
     * Parse a set of arguments and extract the options.
     *
     * @param args The arguments to parse.
     * @throws OptionException If an error is detected.
     */

    public void parseArgs(String[] args) throws OptionException {

	// Reset the tables and lists

	seenOpts = new HashMap();
	remainingArgs = new LinkedList();

	// Process the arguments

	int p = 0;
	while (p < args.length) {
	    String arg = args[p++];

	    // Check for then end of arguments token

	    if (arg.equals("--"))
		while (p < args.length)
		    remainingArgs.add(args[p++]);

	    // Check for a longopt

	    else if (arg.startsWith("--")) {

		// Check if the option is the form --option=value

		arg = arg.substring(2);
		String value = null;
		int i = arg.indexOf('=');
		if (i != -1) {
		    if (i < (arg.length() - 1))
			value = arg.substring(i + 1);
		    arg = arg.substring(0, i);
		}

		// Look up the option

		Option option = (Option) longOpts.get(arg);
		if (option == null)
		    throw new OptionException("Found illegal option: " + arg);

		// Get it's value if we haven't already

		if (option.takesArgument()) {

		    // Try to get the next argument as the value if it was not defined with '='

		    if ((value == null) && (p < args.length) && ! args[p].startsWith("-"))
			value = args[p++];

		    if (option.requiresArgument() && (value == null))
			throw new OptionException("Option " + arg + " requires a value");

		} else if (! option.takesArgument() && (value != null))
		    throw new OptionException("Option " + arg + " can not have a value");

		// Save the parsed option (checking fro duplicates)

		if (seenOpts.get(option) == null)
		    seenOpts.put(option, value);
		else
		    throw new OptionException("Duplicate option: " + arg);

	    // Check for short opts

	    } else if (arg.startsWith("-")) {

		// Process each of the characters as options

		arg = arg.substring(1);
		for (int i = 0; i < arg.length(); i++) {

		    // Get the option

		    char opt = arg.charAt(i);
		    Option option = (Option) shortOpts.get(new Character(opt));
		    if (option == null)
			throw new OptionException("Found illegal option: " + opt);

		    // Try to get its value

		    String value = null;
		    if (option.takesArgument()) {

			// Try to get the next argument as the value if it was not defined with '='

			if ((p < args.length) && ! args[p].startsWith("-"))
			    value = args[p++];

			if (option.requiresArgument() && (value == null))
			    throw new OptionException("Option " + arg + " requires a value");
		    }

		    // Save the parsed option (checking fro duplicates)

		    if (seenOpts.get(option) == null)
			seenOpts.put(option, value);
		    else
			throw new OptionException("Duplicate option: " + opt);
		}

	    // Non-option argument

	    } else
		remainingArgs.add(arg);
	}

	// Check that we saw all required argments

	for (Iterator iterator = allOptions.iterator(); iterator.hasNext();) {
	    Option option = (Option) iterator.next();
	    if (option.isRequired() && ! seenOpts.keySet().contains(option))
		throw new OptionException("Missing required option: " + (option.getLongOpt() != null ? option.getLongOpt() : "" + option.getShortOpt()));
	}
    }

    /**
     * Check if a long Option was seen.
     *
     * @param longOpt The string for the long option to check.
     * @return true if it was seen, false otherwise.
     */

    public boolean sawOption(String longOpt) throws OptionException {

	Option option = (Option) longOpts.get(longOpt);
	if (option != null)
	    return seenOpts.keySet().contains(option);
	else
            return false;
    }

    /**
     * Check if a short Option was seen.
     *
     * @param shortOpt The string for the short option to check.
     * @return true if it was seen, false otherwise.
     */

    public boolean sawOption(char shortOpt) throws OptionException {

	Option option = (Option) shortOpts.get(new Character(shortOpt));
	if (option != null)
	    return seenOpts.keySet().contains(option);
	else
            return false;
    }

    /**
     * Get the value for a long option.
     *
     * @param longOpt The string for the long option to get the value for.
     * @return The value or null if there was none.
     */

    public String getOption(String longOpt) {

	Option option = (Option) longOpts.get(longOpt);
	if (option != null) {

	    // Return the value for the option or it's default value if there was none

	    String value = (String) seenOpts.get(option);
	    return (value != null ? value : option.getDefaultValue());
	} else
	    return null;
    }

    /**
     * Get the value for a short option.
     *
     * @param shortOpt The character for the short option to get the value for.
     * @return The value or null if there was none.
     */

    public String getOption(char shortOpt) {

	Option option = (Option) shortOpts.get(new Character(shortOpt));
	if (option != null) {

	    // Return the value for the option or it's default value if there was none

	    String value =  (String) seenOpts.get(option);
	    return (value != null ? value : option.getDefaultValue());
	} else
	    return null;
    }

    /**
     * Get the unprocessed args.
     *
     * @return The arguments that were not processed as options, this list will be empty if there are no reamainging args.
     */

    public List getRemainingArgs() {
	return remainingArgs;
    }

    // Inner Classes

    /**
     * Information about a specific option.
     */

    public static class Option {

	/** The short form of the option. */

	private char shortOpt;

	/** The long form of the opton. */

	private String longOpt;

	/** A description of the option. */

	private String description;

	/** Argument info */

	private int argInfo;

	/** A flag to indicate if the option is required. */

	private boolean required;

	/** The default value for the option. */

	private String defaultValue;

	/**
	 * Create an Option.
	 *
	 * @param shortOpt The short form of the option. If this is (int) 0 this will be assume to not be used.
	 * @param longOpt The long form of the opton. This may be null.
	 * @param description A description of the option. This may be null.
	 * @param argInfo Information about the argument, on of NO_ARGUMENT, OPTIONAL_ARGUMENT or REQUIRED_ARGUMENT
	 * @param required A flag to indicate if the option is requred.
	 * @param defaultValue The default value for the option, this may be null.
	 */

	public Option(char shortOpt, String longOpt, String description, int argInfo, boolean required, String defaultValue) {

	    this.shortOpt = shortOpt;
	    this.longOpt = longOpt;
	    this.description = description;
	    this.argInfo = argInfo;
	    this.required = required;
	    this.defaultValue = defaultValue;
	}

	/**
	 * Get the sort form of the argument.
	 *
	 * @return The shor form of the argument.
	 */

	public char getShortOpt() {
	    return shortOpt;
	}

	/**
	 * Get the long form of the argument.
	 *
	 * @return The long form of the argument
	 */

	public String getLongOpt() {
	    return longOpt;
	}

	/**
	 * Get a description of the argument.
	 *
	 * @return A description of the argument.
	 */

	public String getDescription() {
	    return description;
	}

	/**
	 * Check if this option is required.
	 *
	 * @return true if the option is required, false otherwise.
	 */

	public boolean isRequired() {
	    return required;
	}

	/**
	 * Get the default value for the option.
	 *
	 * @return The default value for the option, this may be null.
	 */

	public String getDefaultValue() {
	    return defaultValue;
	}

	/**
	 * Check if this option can have an argument.
	 *
	 * @return true if the option can have an argument.
	 */

	public boolean takesArgument() {
	    return argInfo != NO_ARGUMENT;
	}

	/**
	 * Check if this option requries an argument.
	 *
	 * @return true if an argument is required, false otherwise.
	 */

	public boolean requiresArgument() {
	    return argInfo == ARGUMENT_REQUIRED;
	}
    }

    /**
     * Exception thrown when parsing options.
     */

    public static class OptionException extends Exception {

	/**
	 * Create an OptionException.
	 *
	 * @param message The error message.
	 */

	public OptionException(String message) {
	    super(message);
	}
    }
}
