package com.binaryblizzard.growl;

import com.binaryblizzard.util.Options;
import com.binaryblizzard.util.Log;

import java.util.List;
import java.net.Socket;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 * This is a Java program that can connect to a ncid server (ncid.sourceforge.net) and forward caller ID's as
 * Growl notifications to a target host or network.
 *
 * @version $Revision: 1.1 $
 * @author Stephen Martin
 *
 * Copyright 2006 Stephen Martin, Binary Blizzard Software. All rights reserved.
 */

public class NcidToGrowl extends Thread {

    /** The Growl application name. */

    private static final String APPLICATION_NAME = "Caller ID";

    /** The NCID server port. */

    private static final int NCID_PORT = 3333;

    /** The NCID server to connect to. */

    private InetAddress ncidAddress;

    /** The Grow object to use to forward notifications. */

    private Growl growl;

    /**
     * Craete a NcidToGrowl converter.
     *
     * @param ncidServer The NCID server host.
     * @param growlHost The host or network to send growl notifications to.
     * @param growlPassword The growl network password, this may be null.
     * @throws GrowlException If an error occurs creating the Growl object.
     * @throws UnknownHostException If the NCID server host is not known
     */

    public NcidToGrowl(String ncidServer, String growlHost, String growlPassword) throws GrowlException, UnknownHostException {

        ncidAddress = InetAddress.getByName(ncidServer);

        // Create and configure the Growl object to send notifications for "Caller ID"

        growl = new Growl();
        growl.addGrowlHost(growlHost, growlPassword);
        GrowlRegistrations registrations = growl.getRegistrations(APPLICATION_NAME);
        registrations.registerNotification(APPLICATION_NAME, true);
    }

    /**
     * Convert MCID messages in the form:
     *
     *   CID: *DATE*10112006*TIME*0943*LINE*-*NMBR*8005551212*MESG*NONE*NAME*John Doe
     *
     * to a growl message
     *
     * @param msg The line to convert
     */

    private void convertNcidToGrowl(String msg) {

        // Ignore empty messages or those not starting with "CID:"

        Log.debug("Converting Growl message: " + msg);
        if (! msg.startsWith("CID:"))
            return;

        // Split the line into fields, currently we are only interested in the NMBR and NAME fields

        String[] fields = msg.split("\\*");
        try {
            String description = "Caller: " + fields[12] + "\nNumber: " + fields[8];
            growl.sendNotification(new GrowlNotification(APPLICATION_NAME, APPLICATION_NAME, description, APPLICATION_NAME, false, GrowlNotification.HIGH));
        } catch (GrowlException ge) {
            Log.error("Growl Exception", ge);
        }
    }

    /** @see Thread#run() */

    public void run() {

        // This should run until the program is killed

        while (true)
            try {

                // Attempt to connect to the NCID server

                Log.debug("Connecting to NCID server " + ncidAddress + " port " + NCID_PORT);
                Socket socket = new Socket(ncidAddress, NCID_PORT);
                BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));

                // Read from the server and convert the messages

                String line;
                while ((line = reader.readLine()) != null)
                    convertNcidToGrowl(line.trim());

                // If we get here, the server must have closed the connection or went away

                socket.close();

            } catch (IOException ioe) {


                // This is probably caused by the NCID server being down, wait for a minute and try again

                Log.debug("NCID connection failed: " + ioe.getMessage());
                try {Thread.sleep(60000);} catch (InterruptedException ie) {}
            }
    }

    /**
     * A Program that connects to a NCID server and forwards all Caller ID's received to growl.
     *
     * @param args Usage: java com.binaryblizzard.growl.NcidToGrowl [-p <growl password>] <ncid server> <growl host>
     */

    public static void main(String[] args) {

	try {

            // Process the command line options

            Options options = new Options("NcidToGrowl", "An NCID to Growl converter");
            options.addOption("password", 'p', false, Options.ARGUMENT_REQUIRED, null, "The Growl network password");
            options.addOption("debug", 'd', false, Options.NO_ARGUMENT, null, "The debug flag");
            options.parseArgs(args);

            List remainingArgs = options.getRemainingArgs();
            if (remainingArgs.size() != 2) {
                System.err.println("Usage: java com.binaryblizzard.growl.NcidToGrowl [-p <growl password>] <ncid server> <growl host>");
                System.exit(-1);
            }
            String ncidServer = (String) remainingArgs.get(0);
            String growlHost = (String) remainingArgs.get(1);
            Log.setDebug(options.sawOption("debug"));

            // Create and start the converter

            NcidToGrowl ncidToGrowl = new NcidToGrowl(ncidServer, growlHost, options.getOption("password"));
            ncidToGrowl.start();

        } catch (Exception ex) {

            // Report the exception and exit

            ex.printStackTrace();
            System.exit(-1);
        }
    }
}
