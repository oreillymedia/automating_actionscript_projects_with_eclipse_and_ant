//
// $Id: JGrowl.java,v 1.1 2006/10/17 22:06:25 smartin Exp $
//

// Packages

package com.binaryblizzard.growl;

import com.binaryblizzard.util.Options;
import org.jdesktop.jdic.tray.SystemTray;
import org.jdesktop.jdic.tray.TrayIcon;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;

/**
 * A simple Swing program to display Growl notifications.
 *
 * @version $Revision: 1.1 $
 * @author Stephen Martin
 *
 * Copyright 2006 Stephen Martin, Binary Blizzard Software. All rights reserved.
 */

public class JGrowl implements GrowlListener {

    /** The Growl Icon */

    ImageIcon icon  = new ImageIcon(getClass().getResource("/com/binaryblizzard/growl/growl.png"));

    /** A table of registrations by application name. */

    private final Map<String, GrowlRegistrations> growlRegistrations = new HashMap<String, GrowlRegistrations>();

   /** A list of active notification Windows. */

    private final java.util.List<NotificationWindow> activeWindows = new LinkedList<NotificationWindow>();

    /** A pool of inactive notification Windows. */

    private final java.util.List<NotificationWindow> windowPool = new LinkedList<NotificationWindow>();

    /**
     * Create a JGrowl object.
     *
     * @param password The password to use to sign notifications that this program will display
     * @throws GrowlException If there is an error creating the Growl Object
     */

    public JGrowl(String password) throws GrowlException {

	// Create the growl object to use to listen for notifications

	Growl growl = new Growl();
	growl.listenForGrowls(this, password);

        try {

            // Try to create the Tray icon and menu

            SystemTray systemTray = SystemTray.getDefaultSystemTray();
            JPopupMenu trayMenu = new JPopupMenu("JGrowl");
            TrayIcon trayIcon = new TrayIcon(icon, "JGrowl", trayMenu);
            trayIcon.setIconAutoSize(true);
            systemTray.addTrayIcon(trayIcon);

            // Add an exit item to the menu

            JMenuItem exit = new JMenuItem("Exit");
            exit.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    System.exit(0);
                }
            });
            trayMenu.add(exit);

        } catch (Throwable throwable) {

            // If we get an error here it means that there was some sort of problem loading the jdic library, this
            // is not critical so just report it and continue

            System.err.println("Error creating tray icon: " + throwable.getMessage());
        }
    }

    /**
     * Show a notifcation.
     *
     * @param notification The GrowlNotification to show.
     */

    private void showNotification(final GrowlNotification notification) {

	try {

	    SwingUtilities.invokeAndWait(new Runnable() {
		public void run() {

		    synchronized (JGrowl.this) {

			// Get or create a notification window and add it to the active windows list

			NotificationWindow notificationWindow;
			if (windowPool.size() == 0)
			    notificationWindow = new NotificationWindow();
			else
			    notificationWindow = windowPool.remove(0);
			notificationWindow.setNotification(notification);

			// Position the window

			double y = 0;
                        for (NotificationWindow window : activeWindows) {
                            Point loc = window.getLocationOnScreen();
                            if (loc.getY() >= y) {
                                Dimension dim = window.getSize();
                                y = loc.getY() + dim.getHeight();
                            }
                        }

                        // Display it

                        activeWindows.add(notificationWindow);
			notificationWindow.setLocation(0, + (int) y);
			notificationWindow.setVisible(true);
		    }
		}
	    });

	} catch (Exception ex) {
	    ex.printStackTrace();
	}
    }

    /**
     * Return a window to the pool.
     *
     * @param window The window to return to the pool.
     */

    private synchronized void returnWindowToPool(NotificationWindow window) {
	activeWindows.remove(window);
	windowPool.add(window);
    }

    /** @see GrowlListener#receiveNotification(GrowlNotification) */

    public void receiveNotification(GrowlNotification notification) {

	// Check if the notification is registered and enabled, otherwise just ignore it

	GrowlRegistrations registrations = growlRegistrations.get(notification.applicationName);
	if ((registrations != null) && registrations.isEnabled(notification.notification))
	    showNotification(notification);

    }

    /** @see GrowlListener#receiveRegistrations(GrowlRegistrations) */

    public void receiveRegistrations(GrowlRegistrations registrations) {
	growlRegistrations.put(registrations.applicationName, registrations);
    }

    /**
     * The main.
     *
     * @param args Usage: java com.binaryblizzard.growl.JGrowl [-p <password>]
     */

    public static void main(String[] args) {

	try {

            // Process the command line options

            final Options options = new Options("JGrowl", "A Java Swing implementation of Growl");
            options.addOption("password", 'p', false, Options.ARGUMENT_REQUIRED, null, "The Growl network password");
            options.parseArgs(args);

            // Create and start growl

            SwingUtilities.invokeAndWait(new Runnable() {
                public void run() {
                    try {
                        new JGrowl(options.getOption("password"));
                    } catch (GrowlException ge) {
                        ge.printStackTrace();
                        System.exit(-1);
                    }
                }
            });

        } catch (Exception ex) {
	    ex.printStackTrace();
	}
    }

    // Inner Classes

    /**
     * A window to show notifications in.
     */

    private class NotificationWindow extends JWindow implements ActionListener, MouseListener {

	/** The amount of time to display the notifications on the screen by priority. */

	private final int[] delays = {1000, 3000, 5000, 7000, 10000};

	/** The window background colour by priority. */

	private final Color[] colours = {new Color(0xffffff), new Color(0xffcc66), new Color(0xffff99), new Color(0x00cc99), new Color(0xff3366)};

	/** The notification title is shown as a border. */

	private TitledBorder title;

	/** The notification description. */

	private Box description;

	/** A timer to use to hide the window after a period of time. */

	private Timer timer;

	/**
	 * Create a NotificationWindow.
	 */

	public NotificationWindow() {

	    // Configure the window

	    Container contentPane = getContentPane();
	    GridBagLayout gbl = new GridBagLayout();
	    contentPane.setLayout(gbl);
	    GridBagConstraints gbc = new GridBagConstraints();
	    gbc.insets = new Insets(5, 5, 5, 5);

	    // Create a simple container to show the title and the description

	    Box box = Box.createVerticalBox();
	    getContentPane().add(box, gbc);

	    // The notification title is shown as the title part of a Border

	    title = BorderFactory.createTitledBorder("");
	    box.setBorder(title);

	    // Create a container to hold the lines of the description

	    Box container = Box.createHorizontalBox();
	    box.add(container);
	    container.add(Box.createHorizontalStrut(5));
	    container.add(new JLabel(icon));
	    container.add(Box.createHorizontalStrut(5));
	    description = Box.createVerticalBox();
	    container.add(description);
	    container.add(Box.createHorizontalGlue());
	    container.add(Box.createHorizontalStrut(5));
	    box.add(Box.createVerticalStrut(5));

	    // Create a timer to hide the window and move it back to the pool

	    timer = new Timer(5000,this);
	}

	/**
	 * Set the notification being displayed in this window.
	 *
	 * @param notification The notification to display.
	 */

	public void setNotification(GrowlNotification notification) {

	    // Set the title

	    title.setTitle(notification.title);
	    getContentPane().setBackground(colours[notification.priority + 2]);

	    // Add the description to the box one line at a time

	    String[] lines = notification.description.split("\n");
	    description.removeAll();
            for (String line : lines)
                description.add(new JLabel(line));

            // Resize the window

	    pack();

	    // For none sticky notifications, set the timer to close the window, otherwise, set the window to listen for
	    // mouse clicks

	    if (! notification.sticky) {
		timer.setDelay(delays[notification.priority + 2]);
		timer.start();
	    } else
	        addMouseListener(this);
	}

	/** @see ActionListener@actionPerformed*/

	public void actionPerformed(ActionEvent actionEvent) {

	    // Hide the window and return it to the pool

	    setVisible(false);
            timer.stop();
	    returnWindowToPool(this);
	}

	/** @see MouseListener#mouseClicked(java.awt.event.MouseEvent) */

	public void mouseClicked(MouseEvent event) {

	    // Hide the window and return it to the pool

	    removeMouseListener(this);
	    setVisible(false);
	    returnWindowToPool(this);
	}

	/** @see MouseListener#mousePressed(java.awt.event.MouseEvent) */

	public void mousePressed(MouseEvent event) {
	}

	/** @see MouseListener#mouseReleased(java.awt.event.MouseEvent) */

	public void mouseReleased(MouseEvent event) {
	}

	/** @see MouseListener#mouseEntered(java.awt.event.MouseEvent) */

	public void mouseEntered(MouseEvent event) {
	}

	/** @see MouseListener#mouseExited(java.awt.event.MouseEvent) */

	public void mouseExited(MouseEvent event) {
	}
    }
}
