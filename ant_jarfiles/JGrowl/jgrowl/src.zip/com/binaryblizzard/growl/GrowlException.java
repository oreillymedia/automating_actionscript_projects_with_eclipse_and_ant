//
// $Id: GrowlException.java,v 1.1 2006/10/17 22:06:25 smartin Exp $
//

// Packages

package com.binaryblizzard.growl;

/**
 * Exception thrown by objects in the growl package.
 *
 * @version $Revision: 1.1 $
 * @author Stephen Martin
 *
 * Copyright 2006 Stephen Martin, Binary Blizzard Software. All rights reserved.
 */

public class GrowlException extends Exception {

    /**
     * Create a GrowlException
     *
     * @param msg The error message.
     */

    public GrowlException(String msg) {
        super(msg);
    }

    /**
     * Generate a GrowlException that wraps another exception.
     *
     * @param throwable The exception being wrapped.
     */

    public GrowlException(Throwable throwable) {
        super(throwable);
    }
}
