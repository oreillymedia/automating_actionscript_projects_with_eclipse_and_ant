//
// $Id: GrowlRegistrations.java,v 1.1 2006/10/17 22:06:25 smartin Exp $
//

// Packages

package com.binaryblizzard.growl;

import java.util.LinkedList;
import java.util.List;

/**
 * A container class for Growl registrations.
 *
 * @version $Revision: 1.1 $
 * @author Stephen Martin
 *
 * Copyright 2006 Stephen Martin, Binary Blizzard Software. All rights reserved.
 */

public class GrowlRegistrations {

    /** The name of this application for growl registration. */

    public String applicationName;

    /** A List of registered notifications. */

    public List<String> registeredNotifications = new LinkedList<String>();

    /** A list of indexes in the  registeredNotifications that are enabled. */

    public List<Integer> defaults = new LinkedList<Integer>();

    /**
     * Create the growl registrations.
     *
     * @param applicationName The name of the application
     */

    public GrowlRegistrations(String applicationName) {
        this.applicationName = applicationName;
    }

    /**
     * Register a notifcation to the list of registered notifications.
     *
     * @param notification The notification to register.
     * @param enabled A flag to indicate that the notification is enabled.
     */

    public void registerNotification(String notification, boolean enabled) {

        if (enabled)
            defaults.add(registeredNotifications.size());

        registeredNotifications.add(notification);
    }

    /**
     * Check if a registration is enabled
     *
     * @param notification The Notification to check.
     * @return true if the notification is enabled, false otherwise.
     */

    public boolean isEnabled(String notification) {

        // Search the registered notifications for the given one. If it's found check to see if its
        // index is in the defaults.

        for (int i = 0; i < registeredNotifications.size(); i++)
            if (registeredNotifications.get(i).equals(notification))
                for (Integer index : defaults) {
                    if (index == i)
                        return true;
                    else if (index > i)
                        return false;
                }

        // Notification was not found

        return false;
    }
}
