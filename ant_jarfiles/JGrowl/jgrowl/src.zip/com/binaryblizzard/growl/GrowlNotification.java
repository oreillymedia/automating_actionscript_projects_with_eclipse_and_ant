//
// $Id: GrowlNotification.java,v 1.1 2006/10/17 22:06:25 smartin Exp $
//

// Packages

package com.binaryblizzard.growl;

/**
 * A container class for growl notifications.
 *
 * @version $Revision: 1.1 $
 * @author Stephen Martin
 *
 * Copyright 2006 Stephen Martin, Binary Blizzard Software. All rights reserved.
 */

public class GrowlNotification {

    // The notification priorities.

    public static final int VERY_LOW = -2;
    public static final int MODERATE = -1;
    public static final int NORMAL = 0;
    public static final int HIGH = 1;
    public static final int EMERGENCY = 2;

    /** The notification name. */

    public String notification;

    /** The notification title. */

    public String title;

    /** The notification description. */

    public String description;

    /** The application name. */

    public String applicationName;

    /** The sticky flag. */

    public boolean sticky;

    /** The notification priority. */

    public int priority;

    /**
     * Create a GrowlNotification.
     *
     * @param notification The notification name.
     * @param title The notification title.
     * @param description The notification description.
     * @param applicationName The application name.
     * @param sticky The sticky flag.
     * @param priority The notification priority.
     */

    public GrowlNotification(String notification, String title, String description, String applicationName, boolean sticky, int priority) {

        this.notification = notification;
        this.title = title;
        this.description = description;
        this.applicationName = applicationName;
        this.sticky = sticky;
        this.priority = priority;
    }

    /** @see Object#toString() */

    public String toString() {
        return "growlNotification[notification=" + notification + ",title=" + title + ",description=" + description + ",applicationName=" + applicationName + ",sticky=" + sticky + ",priority=" + priority + "]";
    }
}
