//
// $Id: GrowlListener.java,v 1.1 2006/10/17 22:06:25 smartin Exp $
//

// Packages

package com.binaryblizzard.growl;

/**
 * Interface implemented by objects that wish to receive Growl events.
 *
 * @version $Revision: 1.1 $
 * @author Stephen Martin
 *
 * Copyright 2006 Stephen Martin, Binary Blizzard Software. All rights reserved.
 */

public interface GrowlListener {

    /**
     * Called to deliver a growl notification to a listener.
     *
     * @param notification The notification recieved.
     */

    public void receiveNotification(GrowlNotification notification);

    /**
     * Called to deliver growl registrations to a listener.
     *
     * @param registrations The registrations received.
     */

    public void receiveRegistrations(GrowlRegistrations registrations);
}
